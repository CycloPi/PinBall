
True Type Font: Bold LED Board-7 version 1.0


EULA
-==-
The font Bold LED Board-7 is freeware for home using only.


DESCRIPTION
-=========-
This is original bold font created in style a LED (Light Emitting Diode) matrix 7*7 units. Latin and Cyrillic code pages are supported.

Files in bold_led_board-7.zip:
       	readme.txt     				this file;
        bold_led_board-7.ttf    		regular true type font;
	bold_led_board-7_screen.png		preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-==================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: January 25 2013